#define FLEN 64

