#define FLEN 32

