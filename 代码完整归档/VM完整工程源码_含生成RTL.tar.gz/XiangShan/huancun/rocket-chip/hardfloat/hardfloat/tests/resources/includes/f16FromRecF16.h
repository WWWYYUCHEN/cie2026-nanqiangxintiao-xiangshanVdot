#define FLEN 16

